#!/usr/bin/env python3
"""Extract audio and key frames from a video file using ffmpeg via imageio-ffmpeg."""

import argparse
import os
import subprocess
import sys


def get_ffmpeg():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        pass
    for name in ("ffmpeg", "ffmpeg.exe"):
        for path in os.environ.get("PATH", "").split(os.pathsep):
            exe = os.path.join(path, name)
            if os.path.isfile(exe) and os.access(exe, os.X_OK):
                return exe
    return None


def run(args, **kwargs):
    print(f"[cmd] {' '.join(args)}")
    result = subprocess.run(args, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        raise RuntimeError(f"Command failed: {' '.join(args)}")
    return result


def main():
    parser = argparse.ArgumentParser(description="Extract audio and key frames from video")
    parser.add_argument("video", help="Path to input video file")
    parser.add_argument("-o", "--outdir", default="./_video_extract", help="Output directory")
    parser.add_argument("--audio", action="store_true", default=True, help="Extract audio")
    parser.add_argument("--frames", action="store_true", default=True, help="Extract frames")
    parser.add_argument("--interval", type=int, default=8, help="Frame interval in seconds")
    args = parser.parse_args()

    ffmpeg = get_ffmpeg()
    if not ffmpeg:
        print("ERROR: ffmpeg not found. Install imageio-ffmpeg: pip install imageio-ffmpeg", file=sys.stderr)
        sys.exit(1)

    os.makedirs(args.outdir, exist_ok=True)

    if args.audio:
        audio_path = os.path.join(args.outdir, "audio.wav")
        run([
            ffmpeg, "-y", "-i", args.video,
            "-vn", "-ac", "1", "-ar", "16000",
            audio_path
        ])
        print(f"Audio saved: {audio_path}")

    if args.frames:
        pattern = os.path.join(args.outdir, "frame_%03d.jpg")
        run([
            ffmpeg, "-y", "-i", args.video,
            "-vf", f"fps=1/{args.interval}",
            pattern
        ])
        frames = sorted(f for f in os.listdir(args.outdir) if f.startswith("frame_") and f.endswith(".jpg"))
        print(f"Frames saved: {len(frames)} frames in {args.outdir}")
        for f in frames:
            print(f"  {f}")

    # Print metadata
    result = subprocess.run([ffmpeg, "-i", args.video], capture_output=True, text=True)
    print("\n--- Video Metadata ---")
    for line in result.stderr.splitlines():
        if any(k in line for k in ("Duration", "Stream", "Video", "Audio", "Metadata")):
            print(line.strip())


if __name__ == "__main__":
    main()
