---
name: video-content-analyzer
agent_created: true
description: Analyze and summarize local video files by extracting key frames and transcribing audio. Use when the user asks to summarize, analyze, or understand the content of a local MP4/MOV/AVI or other video file. Triggers on phrases like "总结视频", "分析视频", "video summary", "summarize this video".
---

# Video Content Analyzer

## Overview

Analyze local video files by extracting representative frames and transcribing audio (if present), then synthesize a comprehensive content summary combining visual and spoken information.

## Workflow

### Step 1: Environment Preparation

1. **Get ffmpeg binary** via `imageio-ffmpeg` (lightweight, bundled binary):
   ```bash
   # Create venv if not exists
   /Users/liujianwei/.workbuddy/binaries/python/versions/3.13.12/bin/python3 -m venv /Users/liujianwei/.workbuddy/binaries/python/envs/default
   # Install via Tsinghua mirror for speed
   /Users/liujianwei/.workbuddy/binaries/python/envs/default/bin/pip install -i https://pypi.tuna.tsinghua.edu.cn/simple imageio-ffmpeg
   # Get ffmpeg path
   /Users/liujianwei/.workbuddy/binaries/python/envs/default/bin/python3 -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"
   ```
2. If `imageio-ffmpeg` fails, fall back to `brew install ffmpeg` (macOS).

### Step 2: Extract Media Assets

Create a temporary directory for extracted assets, then:

1. **Extract audio** as 16kHz mono WAV (optimal for speech recognition):
   ```bash
   ffmpeg -y -i "$VIDEO_PATH" -vn -ac 1 -ar 16000 "$TMP/audio.wav"
   ```
2. **Extract key frames** every 8 seconds:
   ```bash
   ffmpeg -y -i "$VIDEO_PATH" -vf "fps=1/8" "$TMP/frame_%03d.jpg"
   ```
3. **Get video metadata** (duration, resolution, codecs):
   ```bash
   ffmpeg -i "$VIDEO_PATH" 2>&1 | grep -E "Duration|Stream|Video|Audio"
   ```

### Step 3: Visual Analysis

Use the `Read` tool to inspect 5-8 representative frames covering:
- Opening (frame_001)
- ~25%, 50%, 75% marks
- Ending (last frame)

Take notes on: people, objects, text, actions, setting, and any on-screen data (numbers, labels, scales).

### Step 4: Audio Transcription (if audio stream exists)

1. **Install faster-whisper**:
   ```bash
   /Users/liujianwei/.workbuddy/binaries/python/envs/default/bin/pip install -i https://pypi.tuna.tsinghua.edu.cn/simple faster-whisper
   ```
2. **Transcribe with environment variables** (CRITICAL for Chinese model download):
   ```python
   from faster_whisper import WhisperModel
   model = WhisperModel("small", device="cpu", compute_type="int8")
   segments, info = model.transcribe("audio.wav", language="zh", vad_filter=False, beam_size=5)
   ```
3. **Required env vars for model download**:
   - `HF_ENDPOINT=https://hf-mirror.com` (use mirror for mainland China)
   - `HF_HUB_DISABLE_XET=1` (disable xet protocol to avoid 401 errors)
   - `HF_HUB_ENABLE_HF_TRANSFER=0`
4. **Model size guidance**:
   - `small`: Best accuracy for Chinese, ~500MB download, acceptable CPU speed
   - `base`: Faster but lower accuracy for accented/child speech
   - `medium`: Most accurate but slow on CPU
5. **Post-processing**: Review transcript for number errors (e.g., "万" -> "克"), homophone confusions (e.g., "颗" -> "本" for books).

### Step 5: Synthesize Summary

Combine findings into a structured summary:
- **Basic info**: duration, resolution, author/title (from filename if available)
- **Content structure**: chronological breakdown with timestamps
- **Key data**: numbers, measurements, conclusions from the video
- **Visual details**: objects, people, actions observed in frames
- **Spoken content**: key quotes and explanations from transcription
- **Conclusion**: overall theme, purpose, and takeaways

### Step 6: Cleanup

Remove the temporary directory containing extracted frames and audio after the summary is delivered:
```bash
rm -rf "$TMP"
```

## Important Notes

- **Language**: Default to Chinese (`zh`) for transcription. Detect language from filename/context if ambiguous.
- **No audio**: If the video has no audio stream, skip Step 4 and rely entirely on frame analysis.
- **VAD filtering**: `vad_filter=False` is recommended to avoid missing speech segments at the beginning.
- **Frame rate**: For videos >5 minutes, increase interval (e.g., `fps=1/12` for 12s intervals) to reduce context load.
- **Privacy**: All processing is local; no video data leaves the machine.
