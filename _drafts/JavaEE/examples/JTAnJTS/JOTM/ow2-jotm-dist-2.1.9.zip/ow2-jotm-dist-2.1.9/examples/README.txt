For more info about examples, you can look at the README files in the
subdirectories of examples/ directory.
You can also have a look at the examples documentation in the doc/
directory of your JOTM distribution.

List of examples:
----------------
basic   	Very basic example.
jdbc    	Use JTA transactions with JDBC.
jdbc-dist	Use JTA transactions with two JDBC databases.
jms			Use JTA transactions with a JMS server (JORAM)
tomcat		Use JOTM with Tomcat to provide Transaction support to Servlets.
