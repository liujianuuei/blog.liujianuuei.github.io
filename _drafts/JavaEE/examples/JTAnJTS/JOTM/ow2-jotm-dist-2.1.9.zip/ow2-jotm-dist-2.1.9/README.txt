########################################
#                                      #
# JOTM (Java Open Transaction Manager) #
#                                      #
#      an ObjectWeb project            #
#                                      #
########################################

JOTM Documentation
------------------

Please refer to the documentation in the doc/ directory


