package rmi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.rmi.registry.LocateRegistry;

public class StartRmiRegistry 
{

	public static void main(String[] args) throws IOException 
	{
		int port = 1099;
		if ( args.length > 0 ) {
			String portAsString = args[0];
			port = Integer.parseInt ( portAsString );
		}
		
		File lockFile = new File ( "registry.lck" );
		FileLock lock = null;
		try {
			FileOutputStream lockfilestream = new FileOutputStream ( lockFile );
     		lock = lockfilestream.getChannel().tryLock();
     		lockFile.deleteOnExit();
     	} catch ( OverlappingFileLockException failedToGetLock ) {
     		//happens on windows
     		lock = null;
     	} catch ( IOException failedToGetLock ) {
     		//happens on windows
     		lock = null;
     	}
		
		if ( lock != null ) {
			LocateRegistry.createRegistry ( port );
			System.out.println("Registry running...");
			System.out.println("Type ENTER to shutdown.");
			BufferedReader breader = new BufferedReader(new InputStreamReader(
					System.in));
			breader.readLine();
		} else {
			System.out.println ( "The registry already seems to be running..." );
		}
		
		System.exit ( 0 );

	}

}
