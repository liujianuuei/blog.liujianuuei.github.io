
package rmi.payment;

import java.io.Serializable;

import com.atomikos.icatch.Extent;

 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *A result holder for passing both the transaction result
  *and the integer amount for all purchases done on behalf
  *of a card.
  *
  *This class is needed because getPayments returns
  *both an application-level result and a transaction-level
  *result.
  */

public class ResultHolder 
implements Serializable
{
     /**
      *The total amount purchased for a card.
      */
      
    public int amount; 
    
     /**
      *The transaction's extent for the invocation,
      *needed by the invoker.
      */
      
    public Extent extent;
    
     /**
      *Default constructor for serializability.
      */
      
    public ResultHolder(){}
    
     /**
      *Application-level constructor.
      *
      *@param amount The amount.
      *@param extent The extent.
      */
      
    public ResultHolder ( int amount , Extent extent )
    {
        this.amount = amount;
        this.extent = extent; 
    }
    
}
