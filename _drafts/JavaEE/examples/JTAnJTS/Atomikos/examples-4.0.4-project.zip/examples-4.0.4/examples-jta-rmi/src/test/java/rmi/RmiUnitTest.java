package rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

import org.junit.Before;
import org.junit.Test;

import com.atomikos.util.ClassLoadingHelper;

public class RmiUnitTest {

	private static final int DEFAULT_REGISTRY_PORT = 1099;
	
	private ServerLauncher paymentServerLauncher;
	private ServerLauncher portalServerLauncher;

	@Before
	public  void start() throws Exception {
		System.setProperty("java.naming.factory.initial" ,
				"com.sun.jndi.rmi.registry.RegistryContextFactory" );
		System.setProperty(
				"java.naming.provider.url" ,
				"rmi://localhost:1099");
		startRmiRegistry(DEFAULT_REGISTRY_PORT);
		paymentServerLauncher = new ServerLauncher();
		portalServerLauncher = new ServerLauncher();
		paymentServerLauncher.launch("rmi.payment.PaymentServerImp", "setup", "payment_jta.properties");
		portalServerLauncher.launch("rmi.portal.PortalServerImp", "setup", "portal_jta.properties");
	}

	private void startRmiRegistry(int port) throws RemoteException {
		LocateRegistry.createRegistry(port);
	}
	



	@Test
    public  void test()
    throws Exception
    {
		Client.test("PortalServer");
    }
	
	private static class ServerLauncher {
		private Object server;
		private Class<?> serverClazz;
		private CustomClassLoader customClassLoader;
		
		void launch(final String serverClassName, final String startMethodName, final String jtaPropertiesFileName) throws Exception {
			ClassLoader contextCL = Thread.currentThread().getContextClassLoader();
			customClassLoader = new CustomClassLoader(contextCL);
			Runnable r=	new Runnable() {
				public void run() {
					try {
					System.setProperty(
							"com.atomikos.icatch.file",ClassLoadingHelper.loadResourceFromClasspath(ServerLauncher.class, jtaPropertiesFileName).getPath());
					switchToCustomClassLoader();
					serverClazz = Thread.currentThread().getContextClassLoader().loadClass(serverClassName);
					server = serverClazz.newInstance();
					serverClazz.getMethod(startMethodName).invoke(server);
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
			};

			new Thread(r).start();

			waitUntilServerRunning();
		}
		
		private void waitUntilServerRunning() throws InterruptedException {
			Thread.sleep(5000);
		}

		private void switchToCustomClassLoader() {
			Thread.currentThread().setContextClassLoader(customClassLoader);
		}
		
	}
}
