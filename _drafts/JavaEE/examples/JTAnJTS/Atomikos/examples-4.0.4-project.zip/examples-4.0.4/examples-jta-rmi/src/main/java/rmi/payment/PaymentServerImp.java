
package rmi.payment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;
import javax.transaction.TransactionManager;

import com.atomikos.icatch.Extent;
import com.atomikos.icatch.ImportingTransactionManager;
import com.atomikos.icatch.Propagation;
import com.atomikos.icatch.config.UserTransactionService;
import com.atomikos.icatch.config.UserTransactionServiceImp;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.atomikos.icatch.trmi.TrmiConfiguration;
import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

 /**
  *Copyright &copy; 2002-2004, Atomikos. All rights reserved.
  *
  *An implementation of the payment server.
  *This example shows how to set up TransactionsRMI
  *and how to implement invocations that are to be part
  *of a remote transaction. For simplicity, we use
  *a NonXADataSourceBean class, but if recovery is essential
  *then it is imperative to use XA. See the XA examples
  *on how to do that; the RMI aspects of this demo are
  *completely independent of whether you use XA or not.
  */

public class PaymentServerImp
implements PaymentServer
{
    private static final String resourceName = "paymentDB";

	//the user name in the database; change if needed.
    private static String user = "sa";

    //the password for the user; change if needed.
    //the current settings are empty strings, for HypersonicSQL
    private static String passwd = "";

    //the full name of the JDBC driver class
    //change if required
    private static String driverClassName = "org.hsqldb.jdbcDriver";

    //the URL to connect with; this should be a valid DriverManager URL
    //change if needed
    private static String connectUrl = "jdbc:hsqldb:file:NonXaPaymentDB";

    //The transaction service
    private static UserTransactionService uts = null;

    private static AtomikosNonXADataSourceBean ds = null;

      /**
        *Initialize the TM, and setup DB tables if needed.
     * @param confProperties
        */

      public void setup()
      throws Exception
      {
            boolean error = false;
            Connection conn = null;

            //we need to use the usertransactionservice to
            //be able to export/import txs
            uts = new UserTransactionServiceImp();
            uts.init();

            try {
                  conn = getConnection();
                  Statement s = conn.createStatement();
                  try {
                      s.executeQuery ( "select * from Payments" );
                  }
                  catch ( SQLException ex ) {
                      //table not there => create it
                      System.err.println ( "Creating Payments table..." );
                      s.executeUpdate ( "create table Payments ( " +
                            " cardno VARCHAR ( 20 ), amount DECIMAL (19,0) )" );
                      for ( int i = 0; i < 100 ; i++ ) {
                          s.executeUpdate ( "insert into Payments values ( " +
                          "'card"+i +"' , 0 )" );
                      }
                  }
                  s.close();
            }
            catch ( Exception e ) {
                error = true;
                throw e;
            }
            finally {
                closeConnection ( conn , error );

            }


            //Lastly, export the server into JNDI
            UnicastRemoteObject.exportObject ( this );
            javax.naming.Context ctx = new javax.naming.InitialContext();
            ctx.rebind ( "PaymentServer" , this );
            //UnicastRemoteObject.exportObject ( this );
            //Naming.rebind ( "PaymentServer" , this );

            //That concludes setup

      }

      /**
        *Shutdown the TM and the datasource.
        */

      public  void shutdown()
      throws Exception
      {
          //shutdown and wait for active transactions
          //to finish
          uts.
          shutdown ( false );

          //cleanup connection pool
          ds.close();

          UnicastRemoteObject.unexportObject ( this , true );
          javax.naming.Context ctx = new javax.naming.InitialContext();
          ctx.unbind ( "PaymentServer" );



      }


      private static DataSource getDataSource()
      {

          //Setup of NonXADataSource
          //as an alternative to constructing a new instance,
          //this could also be a lookup in JNDI

          if ( ds == null ) {
              //Get an Atomikos non-XA datasource instance; either by
              //constructing one or by lookup in JNDI where available.
              //NOTE: for the sake of this minimal example we don't
              //use JNDI. However, the NonXADataSourceBean can be
              //bound in JNDI whenever required for your application.
              ds = new AtomikosNonXADataSourceBean();
              ds.setUniqueResourceName(resourceName);
              ds.setUser ( user );
              ds.setPassword ( passwd );
              ds.setUrl ( connectUrl );
              ds.setDriverClassName ( driverClassName );
              //OPTIONAL pool size
              ds.setPoolSize ( 1 );
              //OPTIONAL timeout in secs between pool cleanup tasks
              ds.setBorrowConnectionTimeout ( 60 );

              //NOTE: the datasource can be bound in JNDI where available
          }

          return ds;
      }

       /**
        *Utility method to start a transaction and
        *get a connection.
        *This method should be called within a transaction.
        *@return Connection The connection.
        */

      private static Connection getConnection()
      throws Exception
      {
          DataSource ds = getDataSource();
          Connection conn = null;
          //retrieve the TM
          TransactionManager tm = getTransactionManager();

          //First, create a transaction
          //NOTE: for a remote invocation, this will be a SUBtransaction!
          tm.begin();
          conn = ds.getConnection();

          return conn;

      }

      /**
        *Utility method to close the connection and
        *terminate the transaction.
        *This method does all XA related tasks
        *and should be called within a transaction.
        *When it returns, the transaction will be terminated.
        *@param conn The connection.
        *@param error Indicates if an error has
        *occurred or not. If true, the transaction will be rolled back.
        *If false, the transaction will be committed.
        */

      private static void closeConnection ( Connection conn , boolean error )
      throws Exception
      {
          if ( conn != null ) conn.close();

          //retrieve the TM
          TransactionManager tm = getTransactionManager();

          //NOTE: for an invocation we have a SUBtransaction
          //meaning that commit will be tentative, and
          //only permanent after two-phase commit done by the
          //remote transaction server!
          //Also, for a subtransaction, the commit will restore
          //the thread association for the parent transaction.

          if ( error )
                  tm.rollback();
              else
                  tm.commit();

      }

      private static TransactionManager getTransactionManager()
      {
          return new UserTransactionManager();
      }

      private static ImportingTransactionManager
      getImportingTransactionManager()
      {
          return TrmiConfiguration.getImportingTransactionManager();
      }


    /**
      *@see PaymentServer
      */

    public Extent pay ( Propagation propagation, String cardno , int amount )
    throws PaymentServerException, RemoteException
    {
        //false ASA exception happens
        boolean success = true;
        ImportingTransactionManager imptm = getImportingTransactionManager();
        Extent extent = null;
        Connection conn = null;

        try {
            //FIRST: import the transaction into the local server.
            //The second argument specifies that orphan detection
            //should be used (an Atomikos added feature that allows
            //extra quality of service). The third argument specifies
            //that timed-out indoubt transactions should be
            //rolledback (so-called heuristics).
            //After this method returns, the thread will have a local
            //transaction associated to it.
            imptm.importTransaction ( propagation , true , false );

            conn = getConnection();
            Statement s = conn.createStatement();
            String sql = "update Payments set amount = amount + " +
                  amount + " where cardno ='"+cardno+"'";
            int count = s.executeUpdate ( sql );
            if ( count == 0 )
                throw new Exception ( "Invalid card: " + cardno );

            s.close();
        }
        catch ( Exception e ) {
            //e.printStackTrace();
            success = false;
            throw new PaymentServerException ( e.getMessage () );
        }
        finally {

            try {
              //return connection to the pool
                closeConnection ( conn , !success );
           }
           catch ( Exception e ) {
                //happens if subtransaction timed out
                //->make sure that the imported parent
                //transaction does not succeed
                success = false;
           }

            try {
                //VERY IMPORTANT: always indicate to the transaction service
                //whether a call succeeded or not, and get the extent.
                //This finally block is typical for EVERY imported transaction!
                //After this method returns, the executing thread will no longer
                //have any transaction associated to it.

               extent = imptm.terminated ( success );
            }
           catch ( com.atomikos.icatch.RollbackException rb ) {
                //happens if transaction timed out
                throw new RemoteException ( "Transaction timed out" );
            }


        }

        //return the extent to the client
        //NOTE: if an exception happens then no extent will be returned,
        //but that is perfectly OK since the local work will not need to be
        //committed in that case!
        return extent;
    }

     /**
      *@see PaymentServer
      */

    public ResultHolder getPayments ( Propagation propagation , String cardno )
    throws PaymentServerException , RemoteException
    {
        //false ASA exception happens
        boolean success = true;
        ImportingTransactionManager imptm = getImportingTransactionManager();
        ResultHolder res = new ResultHolder();
        Connection conn = null;

        try {
            //FIRST: import the transaction into the local server.
            //The second argument specifies that orphan detection
            //should be used (an Atomikos added feature that allows
            //extra quality of service). The third argument specifies
            //that timed-out indoubt transactions should be
            //rolledback (so-called heuristics).
            //After this method returns, the thread will have a local
            //transaction associated to it.
            imptm.importTransaction ( propagation , true , false );

            conn = getConnection();
            Statement s = conn.createStatement();
            String sql = "select amount from Payments where cardno='"
                                + cardno+"'";
            ResultSet rs = s.executeQuery ( sql );
            if ( rs == null || !rs.next() )
                  throw new Exception ( "Invalid cardno: " +cardno );

            res.amount = rs.getInt ( 1 );
            s.close();
        }
        catch ( Exception e ) {
            //e.printStackTrace();
            success = false;
            throw new PaymentServerException ( e.getMessage () );
        }
        finally {

             try {
              //return connection to the pool
              closeConnection ( conn , !success );
            }
            catch ( Exception e ) {
                //happens if subtransaction timed out
                //->make sure that the imported parent
                //transaction does not succeed
                success = false;
            }

            try {
                //VERY IMPORTANT: always indicate to the transaction service
                //whether a call succeeded or not, and get the extent.
                //This finally block is typical for EVERY imported transaction!
                //After this method returns, the executing thread will no longer
                //have any transaction associated to it.

               res.extent = imptm.terminated ( success );
            }
            catch ( com.atomikos.icatch.RollbackException rb ) {
                //happens if transaction timed out
                throw new RemoteException ( "Transaction timed out" );
            }

        }

        //return the result to the client
        //NOTE: if an exception happens then nothing will be returned,
        //but that is perfectly OK since the local work will not need to be
        //committed in that case!
        return res;
    }


    public static void main ( String[] args )
    {
        BufferedReader breader = null;

        try {

            PaymentServerImp server = new PaymentServerImp();
            server.setup();

            System.out.println ( "Server running..." );
            System.out.println ( "Type ENTER to shutdown." );

            breader =
              new BufferedReader ( new InputStreamReader ( System.in ) );
            breader.readLine();

            server.shutdown();
            System.exit ( 0 );
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
}

