#!/bin/sh
PRODUCT=RMI
. "./setCP.sh"
echo
echo CLEANING UP DB...
`rm -rf PortalDatabase`
PAYMENT_RUNNING=`ls | grep 'payment.lck'`
echo 
if [ -n "$PAYMENT_RUNNING" ]
then
    echo FOUND PAYMENT SERVICE...
    java -classpath "$CLASSPATH" -Dcom.atomikos.icatch.file=portal_jta.properties -Djava.naming.factory.initial=com.sun.jndi.rmi.registry.RegistryContextFactory -Djava.naming.provider.url=rmi://localhost:1099 rmi.portal.PortalServerImp PaymentServer
else 
    echo PLEASE EXECUTE startPaymentServer.sh FIRST!!!
fi


