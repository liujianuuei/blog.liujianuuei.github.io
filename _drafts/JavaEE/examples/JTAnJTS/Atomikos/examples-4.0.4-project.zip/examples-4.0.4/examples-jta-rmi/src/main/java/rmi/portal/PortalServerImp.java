package rmi.portal;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import rmi.payment.PaymentServer;
import rmi.payment.ResultHolder;

import com.atomikos.icatch.CompositeTransaction;
import com.atomikos.icatch.CompositeTransactionManager;
import com.atomikos.icatch.ExportingTransactionManager;
import com.atomikos.icatch.Extent;
import com.atomikos.icatch.Propagation;
import com.atomikos.icatch.config.Configuration;
import com.atomikos.icatch.config.UserTransactionService;
import com.atomikos.icatch.jta.RemoteClientUserTransaction;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.atomikos.icatch.trmi.TrmiConfiguration;
import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;




 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *An implementation of the portal server.
  *This example shows how to set up TransactionsRMI
  *and how to implement invocations that are either
  *separate transactions or all part of one local transaction
  *with client-demarcation.
  */

public class PortalServerImp
implements PortalServer
{
    private static final String resourceName = "portalDB";

	//the user name in the database; change if needed.
    private static String user = "sa";

    //the password for the user; change if needed.
    //the current settings are empty strings, for HypersonicSQL
    private static String passwd = "";

    //the full name of the JDBC driver class
    //change if required
    private static String driverClassName = "org.hsqldb.jdbcDriver";

    //the URL to connect with; this should be a valid DriverManager URL
    //change if needed
    private static String connectUrl = "jdbc:hsqldb:file:NonXaPortalDB";

    //The transaction service
    private static UserTransactionService uts = null;

    //The data source to use
    private static AtomikosNonXADataSourceBean ds = null;

    private static String paymentServer = "PaymentServer";


      /**
        *Initialize the TM, and setup DB tables if needed.
        */

      public void setup()
      throws Exception
      {

            uts = new com.atomikos.icatch.config.UserTransactionServiceImp();

            uts.init();

            TransactionManager tm = new UserTransactionManager();
            tm.setTransactionTimeout ( 15 );


            boolean error = false;
            Connection conn = null;
            try {
                  conn = getConnection();
                  Statement s = conn.createStatement();
                  try {
                      s.executeQuery ( "select * from Stock" );
                  }
                  catch ( SQLException ex ) {
                      //table not there => create it
                      System.err.println ( "Creating Stock table..." );
                      s.executeUpdate ( "create table Stock ( " +
                            " itemId DECIMAL ( 19 ,0 ), amount DECIMAL (19,0) , " +
                            " unitPrice DECIMAL ( 19, 0 ) )" );
                      for ( int i = 0; i < 100 ; i++ ) {
                          s.executeUpdate ( "insert into Stock values ( " +
                          i  + ", 1000 , " + i + " )" );
                      }
                  }
                  s.close();
            }
            catch ( Exception e ) {
                error = true;
                throw e;
            }
            finally {
                closeConnection ( conn , true ,  error );

            }


            //Export the server into RMI
            UnicastRemoteObject.exportObject ( this );

            Context ctx = new InitialContext ();


            FileOutputStream out = new FileOutputStream ( "utx.ser" );
            ObjectOutputStream oout = new ObjectOutputStream ( out );
            oout.writeObject ( new RemoteClientUserTransaction("com.atomikos.portalServerUserTransactionServer",
            		Configuration.getConfigProperties()));
            //oout.writeObject ( new RemoteClientUserTransaction() );
            oout.close();

            ctx.rebind ( "PortalServer" , this );


            //That concludes setup

      }

      /**
        *Shutdown the TM and the datasource.
        */

      public  void shutdown()
      throws Exception
      {
          //shutdown and wait for active transactions
          //to finish
            uts.shutdown ( false );

            //cleanup connection pool
            ds.close();

            UnicastRemoteObject.unexportObject ( this , true );

            //unbind usertx from JNDI

            Context ctx = new InitialContext();
            ctx.unbind ( "PortalServer" );


      }



      private static DataSource getDataSource()
      {
          //Setup of NonXADataSource
          //as an alternative to constructing a new instance,
          //this could also be a lookup in JNDI

          if ( ds == null ) {
              //Get an Atomikos non-XA datasource instance; either by
              //constructing one or by lookup in JNDI where available.
              //NOTE: for the sake of this minimal example we don't
              //use JNDI. However, the NonXADataSourceBean can be
              //bound in JNDI whenever required for your application.
              ds = new AtomikosNonXADataSourceBean();
              ds.setUniqueResourceName(resourceName);
              ds.setUser ( user );
              ds.setPassword ( passwd );
              ds.setUrl ( connectUrl );
              ds.setDriverClassName ( driverClassName );
              //OPTIONAL pool size
              ds.setPoolSize ( 1 );
              //OPTIONAL timeout in secs between pool cleanup tasks
              ds.setBorrowConnectionTimeout ( 60 );

              //NOTE: the datasource can be bound in JNDI where available
          }

          return ds;
      }

       /**
        *Utility method to start a transaction and
        *get a connection.
        *This method should be called within a transaction.
        *@return Connection The connection.
        */

      private static Connection getConnection()
      throws Exception
      {
          DataSource ds = getDataSource();
          Connection conn = null;
          //retrieve the TM
          TransactionManager tm = getTransactionManager();

          //Create a transaction if not yet there
          if ( tm.getTransaction() == null ) tm.begin();
          conn = ds.getConnection();

          return conn;

      }

      /**
        *Utility method to close the connection and
        *terminate the transaction.
        *This method does all XA related tasks
        *and should be called within a transaction.
        *When it returns, the transaction will be terminated.
        *@param conn The connection.
        *@param terminateTransaction If true, then the current tx will also be terminated.
        *@param error Indicates if an error has
        *occurred or not. If true, the transaction will be rolled back.
        *If false, the transaction will be committed.
        */

      private static void closeConnection ( Connection conn , boolean terminateTransaction , boolean error )
      throws Exception
      {
          if ( conn != null ) conn.close();

          //retrieve the TM
          TransactionManager tm = getTransactionManager();
          //get the current tx
          Transaction tx = tm.getTransaction();

          if ( tx != null && terminateTransaction ) {
              if ( error )
                  tm.rollback();
              else
                  tm.commit();
          }

      }

      private static TransactionManager getTransactionManager()
      {
          return new UserTransactionManager();
      }

      private static ExportingTransactionManager
      getExportingTransactionManager()
      {
          return TrmiConfiguration.getExportingTransactionManager();
      }

      private static CompositeTransactionManager
      getCompositeTransactionManager()
      {
          return uts.getCompositeTransactionManager();
      }

     /**
      *@see PortalServer
      */

    public void purchase ( String cardno , int itemId , int quantity )
    throws PortalServerException, RemoteException
    {
        boolean error = false;
        //true ASA exception
        ExportingTransactionManager exptm =
            getExportingTransactionManager();
        Connection conn = null;
        Propagation propagation = null;
        Extent extent = null;

        try {
            //start a transaction
            conn = getConnection();
            Statement s = conn.createStatement();
            String sql = "select unitPrice from Stock " +
                " where itemId = " + itemId;
            ResultSet rs = s.executeQuery ( sql );
            if ( rs == null || !rs.next() )
                  throw new Exception ( "Item not found: " +itemId );
            int price = rs.getInt ( 1 );
            sql = "update Stock set amount = amount - " + quantity +
                    " where itemId = " + itemId;
            s.executeUpdate ( sql );
            s.close();

            //now, set up to delegate payment
            //to do so, get a propagation for the transaction of the current
            //thread.
            propagation = exptm.getPropagation();

            Context ctx = new InitialContext();

            //lookup the payment server
            PaymentServer pserver =
                ( PaymentServer ) ctx.lookup ( paymentServer );
            extent = pserver.pay ( propagation , cardno , quantity*price );

            //add the two-phase commit information after the call is done.
            //this allows our transaction service to contact the remote
            //for two-phase commit
            //NOTE: if an exception happens during the call then the
            //remote will not receive two-phase commit; this is
            //perfectly OK; it allows us to tolerate remote failures
            //and still try an alternative.
            exptm.addExtent ( extent );


        }
        catch ( Exception e ) {
              //e.printStackTrace();
              error = true;
              throw new PortalServerException ( e.getMessage() );
          }
          finally {
              try {
                  //close the connection and commit if appropriate
                  closeConnection ( conn , true , error );

                  //since we had a top-level transaction,
                  //the commit will have dissociated any thread
                  //associations
              }
              catch ( Exception e ) {
                  throw new RemoteException ( e.getMessage() );
              }
          }


    }

    /**
      *@see PortalServer
      */

    public void purchase ( UserTransaction utx , String cardno ,
    int itemId , int quantity )
    throws PortalServerException, RemoteException
    {
        boolean error = false;
        //true ASA exception
        ExportingTransactionManager exptm =
            getExportingTransactionManager();
        CompositeTransactionManager ctm =
            getCompositeTransactionManager();
        CompositeTransaction ct = null;
        Connection conn = null;
        Propagation propagation = null;
        Extent extent = null;

        try {
            //First, we retrieve the transaction specified by utx.
            //This is done by looking up the corresponding
            //composite transaction through the ctm and
            //resuming it. That associates the current thread
            //with that transaction and makes it accessible
            //through all transaction manager interfaces
            ct = ctm.getCompositeTransaction ( utx.toString() );

            if ( ct == null ) {
                //happens if utx is an instance created by
                //another transaction server, or if timed out
                System.out.println ( "Transaction not found: " +
                                     utx.toString() );

                throw new Exception ( "Transaction not found: " +
                    utx.toString() );
            }
            //resume the transaction
            ctm.resume ( ct );

            //start a subtransaction of the resumed transaction
            conn = getConnection();
            Statement s = conn.createStatement();
            String sql = "select unitPrice from Stock " +
                " where itemId = " + itemId;
            ResultSet rs = s.executeQuery ( sql );
            if ( rs == null || !rs.next() )
                  throw new Exception ( "Item not found: " +itemId );
            int price = rs.getInt ( 1 );
            sql = "update Stock set amount = amount - " + quantity +
                    " where itemId = " + itemId;
            s.executeUpdate ( sql );
            s.close();

            //now, set up to delegate payment
            //to do so, get a propagation for the transaction of the current
            //thread.
            propagation = exptm.getPropagation();

            Context ctx = new InitialContext();
            //lookup the payment server
            PaymentServer pserver =
                ( PaymentServer ) ctx.lookup ( paymentServer );
            extent = pserver.pay ( propagation , cardno , quantity*price );

            //add the two-phase commit information after the call is done.
            //this allows our transaction service to contact the remote
            //for two-phase commit
            //NOTE: if an exception happens during the call then the
            //remote will not receive two-phase commit; this is
            //perfectly OK; it allows us to tolerate remote failures
            //and still try an alternative.
            exptm.addExtent ( extent );


        }
        catch ( Exception e ) {
              //e.printStackTrace();
              error = true;
              e.printStackTrace();
              throw new PortalServerException ( e.getMessage() );
          }
          finally {
              try {
                  //close the connection and commit the
                  //SUBtransaction if appropriate;
                  //this does NOT lead to final commit yet
                  //since the CLIENT is in control through
                  //the user transaction!
                  closeConnection ( conn , false , error );
              }
              catch ( Exception e ) {
                  //happens on commit with intermediate timeout
                  //in any case, make sure the client transaction
                  //can not commit; this is for safety
                  try {
                      utx.setRollbackOnly();
                  }
                  catch ( Exception ignore ) {}
                  e.printStackTrace();
                  throw new PortalServerException ( e.getMessage() );
              }
              finally {
                  //in any case: dissociate the thread from the
                  //(still active) transaction, in order to be able
                  //to reuse the thread in other invocations, for
                  //other transactions
                  ctm.suspend();

                  //NOTE: the client is responsible for commit/rollback,
                  //since this method is for client-demarcated transactions!
              }
          }


    }

      /**
       *@see PortalServer
       */

    public int getAmountPurchased ( String cardno )
    throws PortalServerException, RemoteException
    {
        boolean error = false;
        //true ASA exception
        ExportingTransactionManager exptm =
            getExportingTransactionManager();
        TransactionManager tm = getTransactionManager();

        Propagation propagation = null;
        ResultHolder res = null;

        try {
            //start a transaction
            //needed because the payment server expects
            //a propagation context
            tm.begin();

            //now, set up to delegate payment
            //to do so, get a propagation for the transaction of the current
            //thread.
            propagation = exptm.getPropagation();

            Context ctx = new InitialContext();
            //lookup the payment server
            PaymentServer pserver =
                ( PaymentServer ) ctx.lookup ( paymentServer );
            res = pserver.getPayments ( propagation , cardno );

            //add the two-phase commit information after the call is done.
            //this allows our transaction service to contact the remote
            //for two-phase commit
            //NOTE: if an exception happens during the call then the
            //remote will not receive two-phase commit; this is
            //perfectly OK; it allows us to tolerate remote failures
            //and still try an alternative.
            exptm.addExtent ( res.extent );


        }
        catch ( Exception e ) {
              //e.printStackTrace();
              error = true;
              throw new PortalServerException ( e.getMessage() );
          }
          finally {
              try {
                  //commit if appropriate
                  if ( !error )
                      tm.commit();
                  else
                      tm.rollback();
              }
              catch ( Exception e ) {
                  //e.printStackTrace();
                  throw new RemoteException ( e.getMessage() );
              }
          }

          return res.amount;
    }

     /**
      *@see PortalServer
      */

    public int getStock ( int itemId )
    throws PortalServerException , RemoteException
    {

        //This method is purely local

        boolean error = false;
        //true ASA exception
        Connection conn = null;
        int res = -1;

        try {
            //start a transaction
            conn = getConnection();
            Statement s = conn.createStatement();
            String sql = "select amount from Stock " +
                " where itemId = " + itemId;
            ResultSet rs = s.executeQuery ( sql );
            if ( rs == null || !rs.next() )
                  throw new Exception ( "Item not found: " +itemId );
            res = rs.getInt ( 1 );

            s.close();
        }
        catch ( Exception e ) {
              //e.printStackTrace();
              error = true;
              throw new PortalServerException ( e.getMessage() );
          }
          finally {
              try {
                  //close the connection and commit if appropriate
                  closeConnection ( conn , true , error );
              }
              catch ( Exception e ) {
                  throw new RemoteException ( e.getMessage() );
              }
          }

         return res;
    }


    public static void main ( String[] args )
    {
        BufferedReader breader = null;

        if ( args.length !=1 ) {
            System.err.println (
                "Argument required: RMI URL of payment server." );
            System.exit ( 1 );
        }



        try {
            paymentServer = args[0];

            PortalServerImp server = new PortalServerImp();
            server.setup();

            System.out.println ( "Server running..." );
            System.out.println ( "Type ENTER to shutdown." );

            breader =
              new BufferedReader ( new InputStreamReader ( System.in ) );
            breader.readLine();

            server.shutdown();

            System.exit ( 0 );
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
}

