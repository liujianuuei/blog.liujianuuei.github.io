
package rmi;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.transaction.UserTransaction;

import rmi.portal.PortalServer;

 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *A demo client for the portal server example.
  */

public class Client
{
      
      public static void test ( String server ) 
      throws Exception
      {
            Context ctx = null;
            UserTransaction utx = null;
            PortalServer pserver = null;
            String cardno = "card10";
            int itemId = 20;
            int qty = 2;
            int purchased = 0;
            int stock = 0;
            int previousStock = 0;

 
            ctx = new InitialContext();
            
            //assert that the usertx can be found
            try {
                FileInputStream in = new FileInputStream ( "utx.ser" );
                ObjectInputStream oin = new ObjectInputStream ( in );
                utx = ( UserTransaction ) oin.readObject();
                oin.close();
            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
                
            if ( utx == null )
                throw new Exception ( "UserTransaction not found -" +
                "please make sure Client is on same machine as PortalServer, " +
                "and that PortalServer is already running" );

            System.out.println ( "Looking up server..." );
            pserver = ( PortalServer ) ctx.lookup ( server );
            if ( pserver == null )
                throw new Exception ( "PortalServer not running?" );
            System.out.println ( "Server found!" );
            
            //first, get the initial stock
            System.out.println ( "Getting initial stock of item " + itemId + "..." );
            stock = pserver.getStock ( itemId );
            previousStock = stock;
            System.out.println ( "Initial stock is: " + stock );
            
            //get the amount purchased, just for fun
            System.out.println ( "Getting initial amount purchased..." );
            purchased = pserver.getAmountPurchased ( cardno );
            System.out.println ( "Amount purchased is: " + purchased );
            
            //purchase a qty; this should decrease stock by qty
            System.out.println ( "Purchasing " + qty + " of item " + itemId + " with card " + cardno + "..." );
            pserver.purchase ( cardno , itemId , qty );
            System.out.println ( "Purchase OK.");
            
            //check that purchase really worked as it should
            System.out.println ( "Getting new stock of item " + itemId + "..." );
            stock = pserver.getStock ( itemId );
            System.out.println ( "New is: " + stock );
            if (  ( previousStock - stock ) != qty )
                throw new Exception ( "Error: purchase does not work?" );
                
                
            previousStock = stock;
            
            //get amount just for fun
            System.out.println ( "Getting new amount purchased..." );
            purchased = pserver.getAmountPurchased ( cardno );
            System.out.println ( "Amount purchased is: " + purchased );
            
            //now, begin a user transaction and do two purchases within 
            //its scope
             System.out.println ( "Starting client transaction..." );
             utx.begin();
            
            //first purchase: qty decrease in stock
             System.out.println ( "Purchasing " +  qty + " items in transaction..." ); 
            pserver.purchase ( utx , cardno , itemId , qty );
            
            //DISABLED DUE TO CASE 22440: RMI thread reuse incompatible with siblings and nonxadatasource
            //second purchase: another qty decrease in stock
            //System.out.println ( "Purchasing another " +  qty + " items in transaction..." ); 
            //pserver.purchase ( utx , cardno , itemId , qty );
            
            //commit the change: a decrease in qty of the stock
            utx.commit();
            System.out.println ( "Transaction committed!" );
            
            //check the result
            stock = pserver.getStock ( itemId );
            if ( ( previousStock - stock ) != qty ) 
                throw new Exception ( "Error: user-demarcated tx failed?" );
                
            previousStock = stock;
            
            //get amount just for fun
            purchased = pserver.getAmountPurchased ( cardno );
            
            //try to purchase with a fake card and check that stock
            //is not changed since this should fail
            try {
                pserver.purchase ( "fakeCard" , itemId, qty );
            }
            catch ( Exception e ) {
                //this is normal since the card does not exist in the 
                //payment server; as a result, the purchase should
                //NOT have decreased the stock
            }
            
            stock = pserver.getStock ( itemId );
            if ( stock != previousStock ) 
                throw new Exception ( 
                "Error: purchase with fake card has committed?" );
            
            
            
      }

      public static void main ( String[] args ) 
      {
          String server = "";
          
          if ( args.length != 1 ) {
              System.err.println ( "Argument required: RMI URL of PortalServer" );
              System.exit ( 1 );  
          }
          server = args[0];
         
          
          try {
              System.out.println ( "Starting test..." );
              test ( server ); 
          }
          catch ( Exception e ) {
              e.printStackTrace(); 
          }
          finally {
              System.out.println ( "Test done!" ); 
          }
          
      }  
}
