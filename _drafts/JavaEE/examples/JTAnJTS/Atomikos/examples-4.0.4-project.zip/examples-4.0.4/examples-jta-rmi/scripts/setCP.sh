JTA_HOME=`pwd`
CLASSPATH=.
for i in `ls  $JTA_HOME/libs/*.jar`
    do
        CLASSPATH=$CLASSPATH:$i
    done
CLASSPATH=$CLASSPATH:target/classes
export JTA_HOME
echo
