#!/bin/sh

. "./setCP.sh"

export CLASSPATH=$CLASSPATH

echo
echo STARTING REGISTRY...
java -cp "$CLASSPATH" rmi.StartRmiRegistry
