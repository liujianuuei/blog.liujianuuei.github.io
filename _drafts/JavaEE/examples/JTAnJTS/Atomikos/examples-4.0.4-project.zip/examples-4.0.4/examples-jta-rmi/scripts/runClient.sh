#!/bin/sh
PRODUCT=RMI
. "./setCP.sh"
echo
PORTAL_RUNNING=`ls | grep 'portal.lck'`
if [ -n "$PORTAL_RUNNING" ]
then
    echo FOUND PORTAL SERVICE...
    java -classpath "$CLASSPATH" -Djava.naming.factory.initial=com.sun.jndi.rmi.registry.RegistryContextFactory -Djava.naming.provider.url=rmi://localhost:1099 rmi.Client PortalServer 
else
    echo PLEASE EXECUTE startPortalServer.sh FIRST!!!
fi

