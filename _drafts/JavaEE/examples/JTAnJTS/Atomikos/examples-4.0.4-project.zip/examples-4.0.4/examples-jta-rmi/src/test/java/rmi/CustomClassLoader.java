package rmi;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

public class CustomClassLoader extends ClassLoader {

	   
    public CustomClassLoader(ClassLoader parent) {
        super(parent);
    }

    private Class<?> getClass(String name)
        throws ClassNotFoundException {
        String filePath = convertFullyQualifiedClassNameToFilePath(name);
        byte[] b = null;
        try {
            b = loadClassDataFromClassPath(filePath);
            Class<?> c = defineClass(name, b, 0, b.length);
            resolveClass(c);
            return c;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (LinkageError e){
        	e.printStackTrace();
        	return null;
        }
    }

	private String convertFullyQualifiedClassNameToFilePath(String name) {
        String file = name.replace('.', '/') + ".class";
		return file;
	}

    @Override
    public Class<?> loadClass(String name)
        throws ClassNotFoundException {
    	
    	Class<?> ret = findLoadedClass(name);

    	if ( ret == null ) {
    		if(!(name.startsWith("com.atomikos")||name.startsWith("rmi"))) {
    			ret = super.loadClass(name);   			
    		}
    		else {
    			ret = getClass(name);
    		}
    	}
    	return ret;
    }
    
    private byte[] loadClassDataFromClassPath(String name) throws IOException, ClassNotFoundException {
        InputStream stream = getClass().getClassLoader().getResourceAsStream(name);
        if (stream==null) throw new ClassNotFoundException(name);
        int size = stream.available();
        byte buff[] = new byte[size];
        DataInputStream in = new DataInputStream(stream);
        in.readFully(buff);
        in.close();
        return buff;
    }
}