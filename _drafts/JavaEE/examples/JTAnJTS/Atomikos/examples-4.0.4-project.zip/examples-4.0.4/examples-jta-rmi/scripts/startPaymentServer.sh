#!/bin/sh
PRODUCT=RMI
. "./setCP.sh"
echo
echo CLEANING UP DB...
`rm -rf PaymentDatabase`

REGISTRY_RUNNING=`ls | grep 'registry.lck'`
echo 
if [ -n "$REGISTRY_RUNNING" ]
then
    echo FOUND REGISTRY SERVICE...
    java -classpath "$CLASSPATH" -Dcom.atomikos.icatch.file=payment_jta.properties -Djava.naming.factory.initial=com.sun.jndi.rmi.registry.RegistryContextFactory -Djava.naming.provider.url=rmi://localhost:1099 rmi.payment.PaymentServerImp
else 
    echo PLEASE EXECUTE startRegistry.sh FIRST!!!
fi
