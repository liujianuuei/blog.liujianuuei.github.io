package rmi.portal;

 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *A portal server exception
  */

public class PortalServerException
extends Exception
{
    public PortalServerException()
    {
        super(); 
    } 
    
    public PortalServerException ( String msg )
    {
        super ( msg ); 
    }
}
