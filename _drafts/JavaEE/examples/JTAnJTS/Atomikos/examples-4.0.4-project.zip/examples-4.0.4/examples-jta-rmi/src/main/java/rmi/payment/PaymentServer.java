package rmi.payment;

import java.rmi.Remote;
import java.rmi.RemoteException;

import com.atomikos.icatch.Extent;
import com.atomikos.icatch.Propagation;

 /**
  *Copyright &Copy; 2004, Atomikos. All rights reserved.
  *
  *An RMI payment server that accepts payment orders within the 
  *scope of a remote transaction, as indicated by the presence
  *of a propagation argument in each invocation.
  *
  *The purpose of this interface is to show the essentials
  *of transaction propagation: a remote transaction is 
  *imported for each invocation, and the <b>extent</b> of the local
  *work is returned to the remote party (for two-phase commit
  *processing).
  */

public interface PaymentServer
extends Remote
{
     /**
      *Process a payment for the given card.
      *
      *@param propagation The propagation data of the invoker's
      *transaction. This indicates that the service is only to be invoked
      *from within an existing remote transaction.
      *@param cardno The credit card number to use.
      *@param amount The amount to be charged.
      *@return Extent The transaction-service related data that 
      *will be used at the invoker's side to process two-phase
      *commit termination for the invocation.
      *@exception PaymentServerException On payment errors, such as 
      *unknown card.
      *
      *@exception RemoteException Required by RMI.
      */
    
    public Extent pay ( Propagation propagation, String cardno , int amount ) 
    throws PaymentServerException, RemoteException;
    
     /**
      *Retrieve all payments done for a given card number.
      *
      *@param propagation The propagation data of the invoker's
      *transaction. This indicates that the service is only to be invoked
      *from within an existing remote transaction.
      *@param cardno The card number to query for.
      *@return ResultHolder An object that returns both the Extent 
      *(to be used for two-phase commit) and the application-level 
      *reply.
      *@exception PaymentServerException For payment errors, such as 
      *card unknown.
      *@exception RemoteException Required by RMI.
      */
      
    public ResultHolder getPayments ( Propagation propagation , String cardno )
    throws PaymentServerException , RemoteException;
}
