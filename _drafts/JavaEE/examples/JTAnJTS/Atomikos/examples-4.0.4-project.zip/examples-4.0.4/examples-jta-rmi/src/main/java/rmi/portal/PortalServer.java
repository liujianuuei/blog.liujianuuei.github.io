package rmi.portal;

import java.rmi.Remote;
import java.rmi.RemoteException;

import javax.transaction.UserTransaction;

 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *An RMI-based portal server that simulates an eCommerce site.
  *The server can be invoked both for client-demarcated transactions
  *(allowing multiple client invocations to be part of the same transaction)
  *as for server-side transaction demarcation (where each invocation is
  *a separate transaction).
  *
  *It is assumed that implementations will delegate their payment 
  *processing to an instance of PaymentServer.
  *
  *The purpose of this interface is to show the essentials of both
  *client-demarcated transaction management and server-side
  *demarcation.
  */

public interface PortalServer 
extends Remote
{
      /**
       *Purchase a certain quantity of some item, on behalf of some
       *credit card. With this method, the purchase will be one transaction, and
       *terminates as soon as the call returns.
       *
       *@param cardno The credit card number. This must be 
       *one of the predefined card numbers in the payment server.
       *@param itemId The ID of the item to purchase.
       *@param quantity The quantity.
       *@exception PortalServerException On application errors, such as
       *invalid card or not enough stock.
       *@exception RemoteException As required by RMI.
       */
       
     public void purchase ( String cardno , int itemId , int quantity )
     throws PortalServerException, RemoteException;
     
     /**
       *Purchase a certain quantity of some item, on behalf of some
       *credit card. With this method, the purchase will become 
       *part of the specified transaction (represented by utx), and
       *multiple purchases done with the same utx argument
       *will be part of one big transaction.
       *
       *@param utx The user transaction to which the work
       *belongs. This should be an instance of this server,
       *or the transaction will not be recognized!
       *@param cardno The credit card number. This must be 
       *one of the predefined card numbers in the payment server.
       *@param itemId The ID of the item to purchase.
       *@param quantity The quantity.
       *@exception PortalServerException On application errors, such as
       *invalid card or not enough stock.
       *@exception RemoteException As required by RMI.
       */
       
     public void purchase ( UserTransaction utx , String cardno, 
        int itemId, int quantity )
     throws PortalServerException, RemoteException;
     
      /**
       *Get the total amount purchased for some card.
       *
       *This method does not have any transaction-related
       *arguments, so it will be done in one server-side
       *transaction that terminates as soon as the call is done.
       *
       *@param cardno The card.
       *@return int The total amount purchased.
       *@exception PortalServerException On application errors, such as
       *invalid card.
       *@exception RemoteException As required by RMI.
       */
       
     public int getAmountPurchased ( String cardno )
     throws PortalServerException, RemoteException;
     
      /**
       *Get the stock of some item.
       *
       *This method does not have any transaction-related
       *arguments, so it will be done in one server-side
       *transaction that terminates as soon as the call is done.
       *
       *@param itemId The ID of the item.
       *@return int The amount in stock.
       *@exception PortalServerException On application errors, such as
       *invalid itemId.
       *@exception RemoteException As required by RMI.
       */
       
     public int getStock ( int itemId )
     throws PortalServerException , RemoteException;
}

