package rmi.payment;

 /**
  *Copyright &copy; 2004, Atomikos. All rights reserved.
  *
  *A payment server exception
  */

public class PaymentServerException
extends Exception
{
    public PaymentServerException()
    {
        super(); 
    } 
    
    public PaymentServerException ( String msg )
    {
        super ( msg ); 
    }
}
