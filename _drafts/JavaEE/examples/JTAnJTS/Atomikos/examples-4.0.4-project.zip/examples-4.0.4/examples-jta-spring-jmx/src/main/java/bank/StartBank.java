package bank;

import org.apache.activemq.broker.BrokerService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.atomikos.jms.extra.MessageDrivenContainer;

public class StartBank {

	public static void main(String[] args) throws Exception {
		String port = BrokerService.DEFAULT_PORT;
		if (args.length > 1) {
			port = args[0];
		}
		BrokerService broker = new BrokerService();
		// configure the broker
		broker.addConnector("tcp://localhost:" + port);
		broker.start();

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"config.xml");
		Bank bank = (Bank) context.getBean("bank");
		// initialize the bank if needed
		bank.checkTables();

		// retrieve the pool; this will also start the pool as specified in
		// config.xml
		// by the init-method attribute!
		MessageDrivenContainer pool = (MessageDrivenContainer) context
				.getBean("messageDrivenContainer");

		// Alternatively, start pool here (if not done in XML)
		// pool.start();

		System.out.println("Bank is listening for messages...");

	}
}
