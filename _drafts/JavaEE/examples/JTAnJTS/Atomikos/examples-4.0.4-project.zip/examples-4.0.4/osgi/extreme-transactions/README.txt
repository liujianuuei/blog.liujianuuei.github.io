IMPORTANT

You need to run ../transactions-essentials demo first because it is supposed to build a common dependency. 
