package com.atomikos.osgi;

import static org.ops4j.pax.exam.CoreOptions.composite;
import static org.ops4j.pax.exam.CoreOptions.frameworkProperty;
import static org.ops4j.pax.exam.CoreOptions.mavenBundle;
import static org.ops4j.pax.exam.CoreOptions.options;
import static org.ops4j.pax.exam.CoreOptions.systemProperty;
import static org.ops4j.pax.exam.CoreOptions.workingDirectory;

import java.io.IOException;

import org.ops4j.pax.exam.ExamSystem;
import org.ops4j.pax.exam.Option;
import org.ops4j.pax.exam.TestContainer;
import org.ops4j.pax.exam.spi.PaxExamRuntime;


public class EmbeddedOSGiServer {

	private static Option[] configuration() {
		return options(
				frameworkProperty("org.osgi.framework.system.packages").value("org.osgi.framework; version=1.7.0,org.osgi.service.startlevel; version=1.1.0,org.osgi.framework.launch; version=1.1.0,javax.net.ssl,javax.xml.parsers,org.w3c.dom,org.xml.sax,javax.xml.transform.stream,javax.xml.validation,org.w3c.dom.ls,"
						+ "javax.naming,javax.naming.spi,javax.sql,javax.sql.rowset.serial,javax.sql.rowset.spi,javax.sql.rowset,"
						+ "javax.naming.directory,javax.naming.event,javax.naming.ldap,javax.naming.spi,javax.xml.namespace,javax.xml.transform,javax.xml.transform.dom,javax.management,javax.net,javax.management.remote,javax.management.openmbean,javax.security.auth,javax.security.auth.callback,"
						+ "javax.annotation.processing,javax.security.cert,org.xml.sax.helpers,javax.security.auth.login,"
						+ "javax.lang.model,org.ietf.jgss,javax.lang.model.element,javax.lang.model.type,javax.lang.model.util,javax.tools"),
				systemProperty("org.osgi.service.http.port").value("8181"),
				frameworkProperty("osgi.console").value("6666"),
				mavenBundle("org.apache.geronimo.specs", "geronimo-servlet_3.0_spec").version("1.0"),
				mavenBundle("org.osgi", "org.osgi.compendium", "4.3.0"),
				mavenBundle("org.slf4j", "slf4j-api").versionAsInProject(),
				mavenBundle("org.slf4j", "slf4j-simple").versionAsInProject().noStart(),
				composite(paxweb()),
				composite(blueprintBundles()),
				composite(jetty()),
				composite(atomikosBundles()),
				workingDirectory("target/osgi")

		);
	}

	public static  Option[] atomikosBundles() {
		return options(
				
				mavenBundle("javax.transaction", "com.springsource.javax.transaction", "1.1.0"),
				mavenBundle("org.apache.derby", "derby", "10.8.1.2"),
				mavenBundle("com.atomikos", "transactions-osgi-axt").versionAsInProject(),
				mavenBundle("com.atomikos", "osgi-example-db-axt").versionAsInProject(),
				mavenBundle("com.atomikos", "osgi-example-api-axt").versionAsInProject(),
				mavenBundle("com.atomikos", "osgi-example-impl-axt").versionAsInProject(),
				mavenBundle("com.atomikos", "osgi-example-webui-axt").versionAsInProject()
				);
	}

	public static Option[] blueprintBundles() {
		return options(mavenBundle("org.apache.aries.blueprint", "org.apache.aries.blueprint", "1.1.0"),
				mavenBundle("org.apache.aries", "org.apache.aries.util", "1.0.0"),
				mavenBundle("org.apache.aries.proxy", "org.apache.aries.proxy", "1.0.0"));
	}

	private static Option[] paxweb() {
		return options(mavenBundle("org.ops4j.pax.web", "pax-web-spi").version("2.0.2"),
				mavenBundle("org.ops4j.pax.web", "pax-web-extender-war").version("2.0.2"),
				mavenBundle("org.ops4j.pax.web", "pax-web-extender-whiteboard").version("2.0.2"),
				mavenBundle("org.ops4j.pax.web", "pax-web-jetty").version("2.0.2"),
				mavenBundle("org.ops4j.pax.web", "pax-web-runtime").version("2.0.2"),
				mavenBundle("org.ops4j.pax.web", "pax-web-jsp").version("2.0.2"));
	}
	private static Option[] jetty() {
		return options(mavenBundle("org.eclipse.jetty", "jetty-util").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-io").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-http").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-continuation").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-server").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-security").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-xml").version("8.1.4.v20120524"),
				mavenBundle("org.eclipse.jetty", "jetty-servlet").version("8.1.4.v20120524"));
	}


	public static void main(String[] args) throws IOException {
		ExamSystem system = PaxExamRuntime.createServerSystem(configuration());
		
		// create Container (you should have exactly one configured!) and start.
		TestContainer container = PaxExamRuntime.createContainer(system);
		container.start();

	}
}
