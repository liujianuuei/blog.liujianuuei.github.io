package test;

import inventory.InventoryServer;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import junit.framework.Assert;

import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;

import payment.PaymentServer;

import com.atomikos.icatch.tcc.rest.CoordinatorImp;
import com.atomikos.icatch.tcc.rest.MimeTypes;
import com.atomikos.icatch.tcc.rest.TransactionProvider;
import com.atomikos.tcc.rest.ParticipantLink;
import com.atomikos.tcc.rest.Transaction;
@SuppressWarnings({"rawtypes","unchecked"})
public class TccRestIntegrationTest {

	
	private static List coordinatorProviders = new ArrayList();
	private static List participantProviders = new ArrayList();
	private static final String COORDINATOR_BASE_URL = "http://localhost:9200";
	private static final String PAYMENT_BASE_URL = "http://localhost:9100/";
	private static final String INVENTORY_BASE_URL = "http://localhost:9000/";
	
	private static void configureLicensePathForJenkinsBuild() {
		System.setProperty("com.atomikos.icatch.license_folder", ClassLoader.getSystemResource(".").getFile().replaceAll("%20", " "));
	}

	@BeforeClass
	public static void configureServers() {
		
		configureLicensePathForJenkinsBuild();
		participantProviders.add(new JacksonJsonProvider());
		startEmbeddedServer(INVENTORY_BASE_URL, InventoryServer.class, participantProviders);
		startEmbeddedServer(PAYMENT_BASE_URL, PaymentServer.class, participantProviders);
		coordinatorProviders.add(new JacksonJsonProvider());
		coordinatorProviders.add(new TransactionProvider());
		startEmbeddedServer(COORDINATOR_BASE_URL, CoordinatorImp.class, coordinatorProviders);

	}

	private static void startEmbeddedServer(String inventoryBaseUrl, Class<?> resourceClasses, List providers) {
		JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean();
		sf.setProviders(providers);
		sf.setResourceClasses(resourceClasses);
		sf.setAddress(inventoryBaseUrl);
		sf.create();
	}

	private ParticipantLink placeOrder(int orderId) throws JsonParseException, JsonMappingException, IOException {
		WebClient inventoryClient = WebClient.create(INVENTORY_BASE_URL, participantProviders);
		Response resp1 = inventoryClient.path("/inventory/placeOrder").accept("application/json")
				.type("application/json").put(orderId);

		ObjectMapper mapper = new ObjectMapper();
		ParticipantLink participant = mapper.readValue((InputStream) resp1.getEntity(), ParticipantLink.class);
		System.out.println(participant);
		return participant;
	}
	
	private ParticipantLink pay(int orderId) throws JsonParseException, JsonMappingException, IOException {
		WebClient client = WebClient.create(PAYMENT_BASE_URL, participantProviders);
		Response resp2 = client.path("/payment/pay").accept("application/json").type("application/json")
				.put(orderId);
		ObjectMapper mapper = new ObjectMapper();
		ParticipantLink participant = mapper.readValue((InputStream) resp2.getEntity(), ParticipantLink.class);
		System.out.println(participant);
		return participant;
	}
	
	@Test
	public void transactionWithConfirmAcrossTwoRestServices() throws Exception {

		Integer orderId = new Integer(100);	

		ParticipantLink order = placeOrder(orderId);			
		ParticipantLink payment = pay(orderId);
		//any failure up to here will lead to automatic cancellation
		confirm(order, payment);
		//here we are certain that everything was confirmed
	}

	@Test
	public void transactionWithCancelAcrossTwoRestServices() throws Exception {
		Integer orderId = new Integer(200);	

		ParticipantLink order = placeOrder(orderId);			
		ParticipantLink payment = pay(orderId);
		//any failure up to here will lead to automatic cancellation after timeout
		cancel(order, payment);
		//here we have been nice and cancelled early to free up resources at each provider
	}

	private void cancel(ParticipantLink participant1,
			ParticipantLink participant2) {
		Transaction transaction = new Transaction();
		transaction.getParticipantLinks().add(participant1);
		transaction.getParticipantLinks().add(participant2);

		WebClient coordinator = WebClient.create(COORDINATOR_BASE_URL, coordinatorProviders);
		Response resp = coordinator.path("/coordinator/cancel").
				accept(MimeTypes.MIME_TYPE_COORDINATOR_JSON).
				type(MimeTypes.MIME_TYPE_COORDINATOR_JSON)
				.put(transaction);
		System.out.println(resp);
		Assert.assertEquals(204, resp.getStatus());
		
	}

	private void confirm(ParticipantLink participant1,
			ParticipantLink participant2) {
		
		// NOTE: we use the Jackson binding for JSON within CXF here
		// feel free to use any other solution, but make sure to 
		// configure the JSON bindings to drop the Transaction container (root) element or it won't work
		
		Transaction transaction = new Transaction();
		transaction.getParticipantLinks().add(participant1);
		transaction.getParticipantLinks().add(participant2);

		WebClient coordinator = WebClient.create(COORDINATOR_BASE_URL, coordinatorProviders);
		Response resp = coordinator.path("/coordinator/confirm").
				accept(MimeTypes.MIME_TYPE_COORDINATOR_JSON).
				type(MimeTypes.MIME_TYPE_COORDINATOR_JSON)
				.put(transaction);
		System.out.println(resp);
		Assert.assertEquals(204, resp.getStatus());
	}
}
