package payment;

import java.util.Calendar;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.atomikos.tcc.rest.ParticipantLink;

/**
 * Rest service for payment processing. Scheduling a payment probably does not
 * reserve any business resources, so this service is not interested
 * in an explicit cancel callback and relies on purely internal 
 * cleanup (not implemented here for simplicity). 
 * 
 */

@Path("/payment")
public class PaymentServer {

	@Produces("application/json")
	@Consumes("application/json")
	@PUT
	@Path("pay")
	public ParticipantLink schedulePayment(int orderid) {
		
		// not shown: actual payment processing
		
		return createParticipantLinkForConfirmation(orderid);
	}

	private ParticipantLink createParticipantLinkForConfirmation(int orderid) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 40);
		
		ParticipantLink participantLink = new ParticipantLink("http://localhost:9100/payment/" + orderid, calendar.getTimeInMillis());
		return participantLink;
	}

	@PUT // required by TCC confirm
	@Path("/{id}") // application-specific parameter
	@Consumes("application/tcc") // required by TCC
	public void confirmPayment(@PathParam("id") String id) {
		
		// not shown: actual payment processing
		
		System.out.println("CONFIRM  " + id);

	}

}
