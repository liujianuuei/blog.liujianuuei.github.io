package inventory;

import java.util.Calendar;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.atomikos.tcc.rest.ParticipantLink;

/**
 * Inventory service for placing orders. Because orders reserve 
 * scarce business resources for a while, this provider is interested
 * in explicit cancel call-backs from the application so it can 
 * free up resources at the earliest possible moment. It would also need
 * additional internal timeout/cancel logic but for simplicity of the demo
 * this is not implemented here.
 *
 */

@Path("/inventory")
public class InventoryServer {

	@Produces("application/json")
	@Consumes("application/json")
	@PUT
	@Path("placeOrder")
	public ParticipantLink placeOrder(int orderId) {
		
		// not shown: actual order processing logic
		
		return createParticipantLinkForConfirmation(orderId);
	}

	private ParticipantLink createParticipantLinkForConfirmation(int orderId) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, 40);
		
		ParticipantLink participantLink = new ParticipantLink("http://localhost:9000/inventory/" + orderId, calendar.getTimeInMillis());

		return participantLink;
	}

	@PUT // required by TCC confirm
	@Path("/{id}") // application-specific
	@Consumes("application/tcc") // required by TCC
	public void confirmOrder(@PathParam("id") String id) {

		// not shown: actual order confirmation (business) logic
		
		System.out.println("CONFIRM  " + id);

	}

	@DELETE // required by TCC cancel
	@Path("/{id}") // application-specific
	@Consumes("application/tcc") // required by TCC
	public void cancelOrder(@PathParam("id") String id) {
		
		// not shown: actual order cancellation (business) logic
		
		System.out.println("CANCEL   " + id);
	}

}
