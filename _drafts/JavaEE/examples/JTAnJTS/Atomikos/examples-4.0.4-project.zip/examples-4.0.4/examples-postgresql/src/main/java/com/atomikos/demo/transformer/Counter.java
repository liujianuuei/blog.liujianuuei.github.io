package com.atomikos.demo.transformer;

public class Counter {

	
	public static int totalMessages=0;
	
	public static int counter=0;
	
	
}
